import { renderPost, renderUser } from "./controllers";
// importamos el modulo para leer entrada del usuario
import * as readline from 'readline';

// configurar la interfaz para leer input de consola
const rl = readline.createInterface({
  input: process.stdin, // entrada de datos
  output: process.stdout // salida de datos
});

// funcion que muestra el menu
function Menu() {
  console.log("► 1 ◄ Ver Usuarios"); // opcion 1
  console.log("► 2 ◄ Ver Posts"); // opcion 2

  // pregunta al usuario para elegir una opcion
  rl.question("Seleccione una opción->✨ ", async (opcion) => {
    if (opcion === '1') {
      await renderUser(); //llama a funcion para ver usuarios
    } else if (opcion === '2') {
      await renderPost(); //llama a funcion para ver posts
    } else {
      console.log("Opción no válida✖️"); //en caso de que el usuario no selccione 1 ó 2 se mostrará este mensaje
    }
    rl.close(); // cierra la interfaz al terminar
  });
}

//ejecuta el menu
Menu();
