Datos de la descripción del proyecto
